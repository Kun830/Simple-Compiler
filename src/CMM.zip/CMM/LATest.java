package CMM;

import CMM.LA.LAnalyzer;
import CMM.SA.SATreeNode;
import CMM.SA.SAnalyzer;
import CMM.util.Word;
import Grammar.Main;
import util.FileExecutor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LATest {
    public static void main(String argv[]) throws IOException {
        LAnalyzer lAnalyzer = new LAnalyzer();
        ArrayList<Word> words = lAnalyzer.execute("in.txt");
        lAnalyzer.show();
    }
}
