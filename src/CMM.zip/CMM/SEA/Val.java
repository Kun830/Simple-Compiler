package CMM.SEA;

import CMM.util.EWordKind;

import static CMM.util.EWordKind.*;

public class Val {
    String name;
    EWordKind type;
    Object value;
    Val(){}
}
