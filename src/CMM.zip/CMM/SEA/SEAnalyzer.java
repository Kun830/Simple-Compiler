package CMM.SEA;

import CMM.SA.SATreeNode;
import CMM.util.EAWordKind;
import CMM.util.EWordKind;
import CMM.util.ErrorExecutor;
import org.omg.CORBA.INTERNAL;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

import static CMM.util.EAWordKind.*;

public class SEAnalyzer {
    SATreeNode root;
    ArrayList<ArrayList<Val>> valTable;
    public SEAnalyzer(SATreeNode node){
        root = node;
        valTable = new ArrayList<>();
    }
    enum JUMPTYPE{
        NOJUMP,
        BREAK,
        CONTINUE
    }

    /**
     * 执行语义分析
     */
    public void Executor(){
        ArrayList<Val> table = new ArrayList<>();
        valTable.add(table);
        for(int i=0;i<root.children.size();i++){
            SATreeNode node = root.children.get(i);
            doStatement(node,table);
        }
        valTable.remove(valTable.size()-1);
    }

    void showError(){
        ErrorExecutor.showError("SEA","语法分析错误",0,0);
    }

    /**
     * statement语义分流
     * @param root
     * @param table
     */
    private JUMPTYPE doStatement(SATreeNode root, ArrayList<Val> table) {
        SATreeNode node = root.children.get(0);
        switch (node.type){
            case WHILE:
                doWhile(node);
                break;
            case IFELSE:
                return doIfElse(node);
            case ASSIGNMENT:
                doAssignment(node);
                break;
            case DECLARATION:
                doDeclaration(node,table);
                break;
            case IN:
                doIn(node);
                break;
            case OUT:
                doOut(node);
                break;
            case JUMP:
                return doJump(node);
        }
        return JUMPTYPE.NOJUMP;
    }

    /**
     * Jump语义执行
     * @param root
     * @return
     */
    private JUMPTYPE doJump(SATreeNode root) {
        SATreeNode node = root.children.get(0);
        if(node.word.type == EWordKind.BREAK){
            return JUMPTYPE.BREAK;
        }
        if(node.word.type == EWordKind.CONTINUE){
            return JUMPTYPE.CONTINUE;
        }
        return JUMPTYPE.NOJUMP;
    }

    /**
     * Print语义执行
     * @param root
     */
    private void doOut(SATreeNode root) {
        SATreeNode node = root.children.get(2);
        Val value = getExpression(node);
        System.out.println(value.value.toString());
    }

    /**
     * Scan语义执行
     * @param root
     */
    private void doIn(SATreeNode root) {
        SATreeNode node = root.children.get(2);
        SATreeNode identifier = node.children.get(0);
        int length=1;
        if(node.children.size()==3){
            SATreeNode number = node.children.get(2);
            if(number.type!=EAWordKind.TOKEN||number.word.type!=EWordKind.INUMBER){
                ErrorExecutor.showError("SEA","缺失整型下标",number.word.line,number.word.position);
            }
            length = Integer.parseInt(number.word.word);
            if(length<=0){
                ErrorExecutor.showError("SEA","下标越界",number.word.line,number.word.position);
            }
        }
        Scanner scan = new Scanner(System.in);
        String input = scan.next();
        changeVariable(identifier.word.word,input,length,identifier.word.line,identifier.word.position);
    }

    /**
     * Declaration语义执行
     * @param root
     */
    private void doDeclaration(SATreeNode root, ArrayList<Val> table) {
        SATreeNode type = root.children.get(0);
        doRestVariable(root,table,type.word.type);
    }

    /**
     * RestVariable语义执行
     * @param root
     * @param table
     * @param type
     */
    void doRestVariable(SATreeNode root, ArrayList<Val> table, EWordKind type){
        if(root.children.size()<1) return;
        SATreeNode variable = root.children.get(1);
        SATreeNode restVariable = root.children.get(2);
        Val val = new Val();
        int length = 1;
        //检查是否存在下标
        if(variable.children.size()>1){
            SATreeNode inumber = variable.children.get(2);
            if(inumber.word.type!=EWordKind.INUMBER){
                ErrorExecutor.showError("SEA","数组大小应该为整数",inumber.word.line,inumber.word.position);
                length=0;
            }
            length = Integer.parseInt(inumber.word.word);
            if(length<=0){
                ErrorExecutor.showError("SEA","数组大小应该为整数",inumber.word.line,inumber.word.position);
                length=0;
            }
        }
        SATreeNode identifier = variable.children.get(0);
        for(int i=0;i<length;i++){
            Val tmp = new Val();
            tmp.type = type;
            tmp.value=0;
            tmp.name = identifier.word.word;
            table.add(tmp);
        }

        doRestVariable(restVariable,table,type);

    }

    /**
     * Assignment语义执行
     * @param root
     */
    private void doAssignment(SATreeNode root) {
        SATreeNode variable = root.children.get(0);
        SATreeNode expression = root.children.get(2);
        Val value = getExpression(expression);
        int length = 1;
        //检查是否存在下标
        if(variable.children.size()>1){
            SATreeNode inumber = variable.children.get(2);
            if(inumber.word.type!=EWordKind.INUMBER){
                ErrorExecutor.showError("SEA","数组大小应该为整数",inumber.word.line,inumber.word.position);
                length=0;
                return;
            }
            length = Integer.parseInt(inumber.word.word);
            if(length<=0){
                ErrorExecutor.showError("SEA","数组大小应该为正数",inumber.word.line,inumber.word.position);
                length=0;
                return;
            }
        }
        SATreeNode identifier = variable.children.get(0);
        changeVariable(identifier.word.word,value.value.toString(),length,identifier.word.line,identifier.word.position);
    }

    /**
     * if else语义执行
     * @param root
     * @return
     */
    private JUMPTYPE doIfElse(SATreeNode root) {
        SATreeNode condition = root.children.get(2);
        SATreeNode ifPart = root.children.get(4);
        JUMPTYPE isJump;

        if(getCondition(condition)){
            //if part scope
            ArrayList<Val> table = new ArrayList<>();
            valTable.add(table);
            if(ifPart.type== STATEMENT) {
                isJump = doStatement(ifPart,table);
            }else{
                isJump = doBlock(ifPart,table);
            }
            valTable.remove(valTable.size()-1);
        }else{
            if(root.children.size()>5){
                SATreeNode elsePart = root.children.get(6);
                //else part scope
                ArrayList<Val> table = new ArrayList<>();
                valTable.add(table);
                if(elsePart.type== STATEMENT) {
                    isJump = doStatement(elsePart,table);
                }else{
                    isJump = doBlock(elsePart,table);
                }
                valTable.remove(valTable.size()-1);
            }else{
                return JUMPTYPE.NOJUMP;
            }
        }
        return isJump;
    }

    /**
     * while语义执行
     * @param node
     */
    private void doWhile(SATreeNode node) {
        SATreeNode condition = node.children.get(2);
        SATreeNode whilePart = node.children.get(4);
        ArrayList<Val> table = new ArrayList<>();
        valTable.add(table);
        while(getCondition(condition)){
            if(whilePart.type==STATEMENT){
                if(doStatement(whilePart,table)==JUMPTYPE.BREAK)
                    return;
            }else{
                if(doBlock(whilePart,table)==JUMPTYPE.BREAK)
                    return;
            }
        }
        valTable.remove(valTable.size()-1);
    }

    /**
     * 处理Block
     * @param root
     * @param table
     * @return
     */
    JUMPTYPE doBlock(SATreeNode root, ArrayList<Val> table){
        JUMPTYPE isJump;
        for(int i=1;i<root.children.size()-1;i++){
            SATreeNode node = root.children.get(i);
            if((isJump=doStatement(node,table))==JUMPTYPE.BREAK)
                return JUMPTYPE.BREAK;
            else if(isJump==JUMPTYPE.CONTINUE)
                return JUMPTYPE.NOJUMP;
        }
        return JUMPTYPE.NOJUMP;
    }

    /**
     * 获取Expression的值
     * @param root
     * @return
     */
    Val getExpression(SATreeNode root){
        SATreeNode node = root.children.get(0);
        Val value = new Val();
        if(node.type== TOKEN){
            value.type = EWordKind.CHAR;
            if(node.word.word.charAt(1)=='\\'){
                switch (node.word.word){
                    case "\\t":
                        value.value = '\t';
                        break;
                    case "\\n":
                        value.value = '\n';
                        break;
                    case "\\r":
                        value.value = '\r';
                        break;
                }
            }else{
                value.value = node.word.word.charAt(1);
            }
        }else{
            value = getCalculation(node);
        }
        return value;
    }

    /**
     * 获取Calculation的值
     * @param root
     * @return
     */
    private Val getCalculation(SATreeNode root) {
        SATreeNode item1 = root.children.get(0);
        SATreeNode item2;
        Val value1 = getItem(item1);
        if(root.children.size()>1){
            Val result = new Val();
            item2 = root.children.get(2);
            Val value2 = getItem(item2);
            SATreeNode operation = root.children.get(1);
            if(value1.type==EWordKind.REAL||value2.type==EWordKind.REAL){
                result.type = EWordKind.REAL;
                if(operation.word.type==EWordKind.PLUS) {
                    result.value = Double.parseDouble(value1.value.toString())
                            + Double.parseDouble(value2.value.toString());
                }
                else{
                    result.value = Double.parseDouble(value1.value.toString())
                            - Double.parseDouble(value2.value.toString());
                }
            }else{
                result.type = EWordKind.INT;
                if(operation.word.type==EWordKind.PLUS) {
                    result.value = Integer.parseInt(value1.value.toString())
                            + Integer.parseInt(value2.value.toString());
                }
                else{
                    result.value = Integer.parseInt(value1.value.toString())
                            - Integer.parseInt(value2.value.toString());
                }
            }
            return result;
        }else{
            return value1;
        }
    }

    /**
     * 获取item的值
     * @param root
     * @return
     */
    private Val getItem(SATreeNode root) {
        SATreeNode item1 = root.children.get(0);
        SATreeNode item2;
        Val value1 = getFactor(item1);
        if(root.children.size()>1){
            Val result = new Val();
            item2 = root.children.get(2);
            Val value2 = getFactor(item2);
            SATreeNode operation = root.children.get(1);
            if(value1.type==EWordKind.REAL||value2.type==EWordKind.REAL){
                result.type = EWordKind.REAL;
                if(operation.word.type==EWordKind.ASTERISK) {
                    result.value = Double.parseDouble(value1.value.toString())
                            * Double.parseDouble(value2.value.toString());
                }
                else{
                    if(Double.parseDouble(value2.value.toString())==0){
                        ErrorExecutor.showError("SEA","除数不为0",item2.word.line,item2.word.position);
                        result.value = new Double(0);
                    }
                    else result.value = Double.parseDouble(value1.value.toString())
                            / Double.parseDouble(value2.value.toString());
                }
            }else{
                result.type = EWordKind.INT;
                if(operation.word.type==EWordKind.ASTERISK) {
                    result.value = Integer.parseInt(value1.value.toString())
                            * Integer.parseInt(value2.value.toString());
                }
                else{
                    if(Integer.parseInt(value2.value.toString())==0){
                        ErrorExecutor.showError("SEA","除数不为0",item2.word.line,item2.word.position);
                        result.value = new Double(0);
                    }
                    else result.value = Integer.parseInt(value1.value.toString())
                            / Integer.parseInt(value2.value.toString());
                }
            }
            return result;
        }else{
            return value1;
        }
    }

    /**
     * 获取factor的值
     * @param root
     * @return
     */
    private Val getFactor(SATreeNode root) {
        if(root.children.size()==1){
            SATreeNode node = root.children.get(0);
            if(node.type== VARIABLE){
                return getVariable(node);
            }else{
                return getNumber(node);
            }
        }else{
            return getCalculation(root.children.get(1));
        }
    }

    /**
     * 获取number的值
     * @param root
     * @return
     */
    private Val getNumber(SATreeNode root) {
        if(root.children.size()>1){
            SATreeNode number = root.children.get(1);
            SATreeNode pm = root.children.get(0);
            Val val = getNumber(number);
            if(pm.word.type==EWordKind.MINUS){
                if(val.type==EWordKind.INT){
                    if((Integer)val.value<0)
                        val.value = Integer.parseInt(val.value.toString().substring(1));
                    else
                        val.value = Integer.parseInt("-"+val.value.toString());
                }else{
                    if((Double)val.value<0)
                        val.value = Double.parseDouble(val.value.toString().substring(1));
                    else
                        val.value = Double.parseDouble("-"+val.value.toString());
                }
            }
            return val;
        }else{
            return getUNumber(root.children.get(0));
        }
    }

    /**
     * 获取unsigned number 值
     * @param root
     * @return
     */
    private Val getUNumber(SATreeNode root) {
        SATreeNode node = root.children.get(0);
        Val val = new Val();
        if(node.word.type==EWordKind.INUMBER){
            val.type = EWordKind.INUMBER;
            val.value = Integer.parseInt(node.word.word);
        }else{
            val.type = EWordKind.FNUMBER;
            val.value = Double.parseDouble(node.word.word);
        }
        return val;
    }

    /**
     * 获取Variable的值
     * @param root
     * @return
     */
    private Val getVariable(SATreeNode root) {
        SATreeNode identifier = root.children.get(0);
        int length = 1;
        if(root.children.size()>1){
            SATreeNode inumber = root.children.get(2);
            if(inumber.word.type!=EWordKind.INUMBER){
                ErrorExecutor.showError("SEA","数组大小应该为整数",inumber.word.line,inumber.word.position);
                length=0;
            }
            length = Integer.parseInt(inumber.word.word);
            if(length<=0){
                ErrorExecutor.showError("SEA","数组大小应该为正数",inumber.word.line,inumber.word.position);
                length=0;
            }
        }
        return getVariable(identifier.word.word,length,identifier.word.line,identifier.word.position);
    }

    /**
     * 获取Condition的值
     * @param root
     * @return
     */
    boolean getCondition(SATreeNode root){
        SATreeNode item1 = root.children.get(0);
        SATreeNode item2;
        boolean value1 = getSubCon(item1);
        if(root.children.size()>1){
            Val result = new Val();
            item2 = root.children.get(2);
            boolean value2 = getSubCon(item2);
            SATreeNode operation = root.children.get(1);
            if(operation.word.type==EWordKind.AND)
                return value1&&value2;
            else return value1||value2;
        }else{
            return value1;
        }
    }

    /**
     * 获取SubCon的值
     * @param root
     * @return
     */
    private boolean getSubCon(SATreeNode root) {
        SATreeNode exp1 = root.children.get(0);
        SATreeNode relation = root.children.get(1);
        SATreeNode exp2 = root.children.get(2);
        Double val1 = Double.parseDouble(getExpression(exp1).value.toString());
        Double val2 = Double.parseDouble(getExpression(exp2).value.toString());
        switch (relation.word.type){
            case SMALLER:
                return val1<val2;
            case SMALLERE:
                return val1<=val2;
            case BIGGER:
                return val1>val2;
            case BIGGERE:
                return val1>=val2;
            case NEQUAL:
                return val1!=val2;
            case EQUAL:
                return val1==val2;
        }
        return false;
    }


    /**
     * 遍历修改最近定义域的符号表中的值
     * @param identifier
     * @param input
     * @param length
     */
    void changeVariable(String identifier, String input, int length,int line,int position){
        for(int i=valTable.size()-1;i>=0;i--){
            ArrayList<Val> scope = valTable.get(i);
            for(int j=0;j<scope.size();j++){
                Val tmp = scope.get(j);
                if(tmp!=null&&tmp.equals(identifier)){
                    if(j+length-1>=scope.size()){
                        ErrorExecutor.showError("SEA","数组越界",line,position);
                        return;
                    }
                    Val value = scope.get(j+length-1);
                    if(value!=null&&value.equals(identifier)){
                        if(value.type==EWordKind.INT){
                            value.value = Integer.parseInt(input);
                        }else if(value.type==EWordKind.REAL){
                            value.value = Double.parseDouble(input);
                        }else if(value.type==EWordKind.CHAR){
                            value.value = (char)input.charAt(0);
                        }
                        return;
                    }else{
                        //越界
                        ErrorExecutor.showError("SEA","数组越界",line,position);
                        return;
                    }
                }
            }
        }
        //没找到
        ErrorExecutor.showError("SEA","未定义符号: "+identifier,line,position);
    }

    /**
     * 遍历查找最近定义域的符号表中的对应值
     * @param identifier
     * @param length
     * @param line
     * @param position
     * @return
     */
    Val getVariable(String identifier, int length,int line,int position){
        for(int i=valTable.size()-1;i>=0;i--){
            ArrayList<Val> scope = valTable.get(i);
            for(int j=0;j<scope.size();j++){
                Val tmp = scope.get(j);
                if(tmp!=null&&tmp.equals(identifier)){
                    if(j+length-1>=scope.size()){
                        ErrorExecutor.showError("SEA","数组越界",line,position);
                        return null;
                    }
                    Val value = scope.get(j+length-1);
                    if(value!=null&&value.equals(identifier)){
                        return value;
                    }else{
                        //越界
                        ErrorExecutor.showError("SEA","数组越界",line,position);
                        return null;
                    }
                }
            }
        }
        return null;
    }
}
